#!/usr/bin/env python3

# Created by Gabriel A
# Created on Nov 2019
# This program calculates the area and perimeter of a rectangle with user input


def main():
    # this function calculates area and perimeter

    # input
    length = int(input("Enter length of the rectangle (cm): "))
    width = int(input("Enter width of the rectangle (cm): "))

    # process
    area = length*width
    perimeter = 2*(length+width)

    # output
    print("")
    print("Area is {}cm2".format(area))
    print("Perimeter is {}cm".format(perimeter))


if __name__ == "__main__":
    main()
